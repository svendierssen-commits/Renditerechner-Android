package de.renditerechner.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/** Native Android UI; visual refresh 2.1 */
public final class MainActivity extends Activity {
    private static final int NAVY = 0xFF16324A;
    private static final int BLUE = 0xFF1F5E87;
    private static final int PETROL = 0xFF17867F;
    private static final int BG = 0xFFF4F7FB;
    private static final int SURFACE = 0xFFFFFFFF;
    private static final int SURFACE_SOFT = 0xFFF8FAFD;
    private static final int TEXT = 0xFF1B3145;
    private static final int MUTED = 0xFF6D7F90;
    private static final int BORDER = 0xFFD9E4ED;
    private static final int ERROR = 0xFFBF4453;
    private static final int WHITE = 0xFFFFFFFF;

    private static final String PREFS = "renditerechner_local";
    private static final String[] MODES = {"Endkapital", "Startkapital", "Sparrate", "Spardauer", "Rendite", "Zielvermögen"};
    private static final String[] TABS = {"Rechner", "Auswertung", "Szenarien", "Einstellungen"};
    private static final NumberFormat EURO = NumberFormat.getCurrencyInstance(Locale.GERMANY);
    private static final NumberFormat NUMBER = NumberFormat.getNumberInstance(Locale.GERMANY);
    private static final DateTimeFormatter DATE_LABEL = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.GERMANY);
    private static final DateTimeFormatter DATE_STORE = DateTimeFormatter.ISO_LOCAL_DATE;

    private SharedPreferences storage;
    private AppState state;
    private int tab = 0;
    private LinearLayout page;
    private TextView mainResult, detailResult, explanation, summaryStart, summaryMonthly, summaryGain;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        storage = getSharedPreferences(PREFS, MODE_PRIVATE);
        try {
            state = AppState.fromJson(new JSONObject(storage.getString("current", "{}")));
        } catch (Exception ignored) {
            state = new AppState();
        }
        render();
    }

    private int dp(float value) { return (int) (getResources().getDisplayMetrics().density * value + .5f); }
    private float dpf(float value) { return getResources().getDisplayMetrics().density * value; }
    private LinearLayout col() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); return x; }
    private LinearLayout row() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); x.setGravity(Gravity.CENTER_VERTICAL); return x; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void gap(LinearLayout parent, int height) { View spacer = new View(this); parent.addView(spacer, lp(1, height)); }

    private GradientDrawable solid(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private GradientDrawable outlined(int color, float radius, int strokeColor) {
        GradientDrawable g = solid(color, radius);
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private GradientDrawable gradient(int startColor, int endColor, float radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{startColor, endColor});
        g.setCornerRadius(dp(radius));
        return g;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView x = new TextView(this);
        x.setText(value);
        x.setTextColor(color);
        x.setTextSize(size);
        if (bold) x.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return x;
    }

    private TextView smallLabel(String value) {
        TextView t = text(value, 12, MUTED, false);
        t.setAllCaps(true);
        t.setLetterSpacing(0.05f);
        return t;
    }

    private void caption(LinearLayout parent, String value) {
        TextView t = text(value, 13, MUTED, false);
        parent.addView(t);
        gap(parent, 6);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = col();
        c.setBackground(outlined(SURFACE, 18, BORDER));
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        if (Build.VERSION.SDK_INT >= 21) c.setElevation(dpf(1.5f));
        LinearLayout.LayoutParams params = lp(-1, -2);
        params.bottomMargin = dp(14);
        parent.addView(c, params);
        return c;
    }

    private TextView sectionTitle(LinearLayout parent, String title, String subtitle) {
        TextView t = text(title, 20, TEXT, true);
        parent.addView(t);
        if (subtitle != null && !subtitle.isEmpty()) {
            gap(parent, 4);
            parent.addView(text(subtitle, 13, MUTED, false));
        }
        return t;
    }

    private Button primaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackground(gradient(BLUE, PETROL, 14));
        return b;
    }

    private Button secondaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(BLUE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackground(outlined(WHITE, 14, BORDER));
        return b;
    }

    private Button chipButton(String value, boolean active) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        b.setBackground(active ? solid(0xFFE6F5F3, 16) : outlined(SURFACE, 16, BORDER));
        b.setTextColor(active ? PETROL : TEXT);
        return b;
    }

    private void persist() { storage.edit().putString("current", state.toJson().toString()).apply(); }

    private void render() {
        LinearLayout root = col();
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets s = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(s.left, s.top, s.right, s.bottom);
                return insets;
            });
        }

        LinearLayout hero = col();
        hero.setPadding(dp(18), dp(16), dp(18), dp(16));
        hero.setBackground(gradient(NAVY, BLUE, 0));
        hero.addView(text("Renditerechner", 24, WHITE, true));
        gap(hero, 4);
        hero.addView(text("Sparen, Ziele planen und Vermögen klar im Blick behalten.", 13, 0xFFD7E8F5, false));
        gap(hero, 16);

        LinearLayout tabWrap = row();
        tabWrap.setGravity(Gravity.LEFT);
        for (int i = 0; i < TABS.length; i++) {
            final int index = i;
            Button tabBtn = chipButton(TABS[i], i == tab);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1);
            if (i > 0) p.leftMargin = dp(8);
            tabWrap.addView(tabBtn, p);
            tabBtn.setOnClickListener(v -> { tab = index; render(); });
        }
        hero.addView(tabWrap);
        root.addView(hero, lp(-1, -2));

        ScrollView scroller = new ScrollView(this);
        page = col();
        page.setPadding(dp(16), dp(16), dp(16), dp(20));
        scroller.addView(page, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1));

        if (tab == 0) showCalculator();
        else if (tab == 1) showAnalysis();
        else if (tab == 2) showSaved();
        else showSettings();

        setContentView(root);
    }

    private double parseDouble(String s, double previous) {
        try {
            String x = s.trim().replace(" ", "").replace("€", "").replace("%", "");
            if (x.indexOf(',') >= 0) x = x.replace(".", "").replace(',', '.');
            else if (x.matches("[-+]?\\d{1,3}(\\.\\d{3})+")) x = x.replace(".", "");
            double d = Double.parseDouble(x);
            return Double.isFinite(d) ? d : previous;
        } catch (Exception e) {
            return previous;
        }
    }

    private EditText editNumber(LinearLayout parent, String title, double value, DoubleConsumer setter, boolean enabled) {
        caption(parent, title);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(17);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setSelectAllOnFocus(true);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(enabled ? outlined(SURFACE_SOFT, 14, BORDER) : solid(0xFFE9EEF3, 14));
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        if (Math.abs(value - Math.rint(value)) < 0.00001) e.setText(Long.toString(Math.round(value)));
        else e.setText(String.format(Locale.GERMANY, "%.3f", value).replaceAll("0+$", "").replaceAll(",$", ""));
        e.setEnabled(enabled);
        LinearLayout.LayoutParams p = lp(-1, 52);
        p.bottomMargin = dp(10);
        parent.addView(e, p);
        if (enabled) {
            e.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (s.length() == 0 || s.toString().equals("-") || s.toString().equals(",")) return;
                    setter.accept(parseDouble(s.toString(), value));
                    persist();
                    refreshResult();
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }
        return e;
    }

    private void editInteger(LinearLayout parent, String title, int value, IntConsumer setter, boolean enabled) {
        editNumber(parent, title, value, d -> setter.accept((int) Math.round(d)), enabled);
    }

    private void switchRow(LinearLayout parent, String title, boolean initial, java.util.function.Consumer<Boolean> setter) {
        LinearLayout wrap = row();
        wrap.setPadding(0, dp(4), 0, dp(8));
        TextView label = text(title, 14, TEXT, false);
        wrap.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(initial);
        if (Build.VERSION.SDK_INT >= 21) {
            sw.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{PETROL, 0xFFBCCAD5}));
        }
        wrap.addView(sw);
        parent.addView(wrap, lp(-1, -2));
        sw.setOnCheckedChangeListener((b, checked) -> { setter.accept(checked); persist(); render(); });
    }

    private LinearLayout statBox(LinearLayout parent, String label) {
        LinearLayout box = col();
        box.setBackground(solid(0x1AFFFFFF, 14));
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.addView(text(label, 12, 0xFFE2F0F8, true));
        TextView value = text("–", 15, WHITE, true);
        value.setPadding(0, dp(6), 0, 0);
        box.addView(value);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
        if (parent.getChildCount() > 0) p.leftMargin = dp(8);
        parent.addView(box, p);
        return box;
    }

    private void showCalculator() {
        LinearLayout resultCard = card(page);
        resultCard.setBackground(gradient(NAVY, BLUE, 22));
        TextView badge = text(state.expert ? "Expertenmodus" : "Einfacher Modus", 12, 0xFFD9EDF5, true);
        badge.setBackground(solid(0x1FFFFFFF, 18));
        badge.setPadding(dp(10), dp(6), dp(10), dp(6));
        resultCard.addView(badge, lp(-2, -2));
        gap(resultCard, 14);
        resultCard.addView(text(state.mode == Finance.END ? "Berechnetes Endkapital" :
                state.mode == Finance.START ? "Benötigtes Startkapital" :
                state.mode == Finance.MONTHLY || state.mode == Finance.GOAL ? "Benötigte monatliche Sparrate" :
                state.mode == Finance.DURATION ? "Benötigte Laufzeit" : "Erforderliche Jahresrendite", 14, 0xFFD9E8F2, false));
        gap(resultCard, 4);
        mainResult = text("–", 31, WHITE, true);
        resultCard.addView(mainResult);
        detailResult = text("", 13, 0xFFC4E2EE, false);
        resultCard.addView(detailResult);
        gap(resultCard, 14);
        LinearLayout stats = row();
        LinearLayout investedBox = statBox(stats, "Eigenes Geld");
        LinearLayout endBox = statBox(stats, "Nach Steuern");
        LinearLayout gainBox = statBox(stats, "Ertrag");
        resultCard.addView(stats, lp(-1, -2));
        summaryStart = (TextView) investedBox.getChildAt(1);
        summaryMonthly = (TextView) endBox.getChildAt(1);
        summaryGain = (TextView) gainBox.getChildAt(1);
        explanation = text("", 13, ERROR, false);
        LinearLayout.LayoutParams expP = lp(-1, -2);
        expP.topMargin = dp(8);
        page.addView(explanation, expP);

        LinearLayout targetCard = card(page);
        sectionTitle(targetCard, "Ziel & Modus", "Lege fest, was du berechnen möchtest.");
        gap(targetCard, 14);
        caption(targetCard, "Berechnungsmodus");
        Spinner mode = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, MODES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mode.setAdapter(adapter);
        mode.setSelection(state.mode);
        targetCard.addView(mode, lp(-1, 50));
        mode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> parent) {}
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (state.mode != position) { state.mode = position; persist(); render(); }
            }
        });
        gap(targetCard, 12);

        LinearLayout toggles = row();
        Button expertButton = chipButton(state.expert ? "Expertenmodus aktiv" : "Zu Expertenoptionen wechseln", state.expert);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, dp(44), 1);
        toggles.addView(expertButton, ep);
        expertButton.setOnClickListener(v -> { state.expert = !state.expert; persist(); render(); });
        Button dateButton = secondaryButton(displayDate(state.startDate));
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(0, dp(44), 1);
        dp2.leftMargin = dp(8);
        toggles.addView(dateButton, dp2);
        dateButton.setOnClickListener(v -> {
            LocalDate d;
            try { d = LocalDate.parse(state.startDate, DATE_STORE); }
            catch (Exception e) { d = LocalDate.now(); }
            new DatePickerDialog(this, (picker, y, m, day) -> {
                state.startDate = LocalDate.of(y, m + 1, day).toString();
                persist();
                render();
            }, d.getYear(), d.getMonthValue() - 1, d.getDayOfMonth()).show();
        });
        targetCard.addView(toggles);

        LinearLayout baseCard = card(page);
        sectionTitle(baseCard, "Basisdaten", state.mode == Finance.GOAL ? "Definiere deinen heutigen Stand und dein Vermögensziel." : "Gib die wichtigsten Eckdaten deines Szenarios ein.");
        gap(baseCard, 14);
        editNumber(baseCard, "Startkapital (€)", state.start, d -> state.start = d, state.mode != Finance.START);
        if (state.mode == Finance.GOAL) {
            editInteger(baseCard, "Heutiges Alter", state.currentAge, v -> state.currentAge = v, true);
            editInteger(baseCard, "Gewünschtes Zielalter", state.targetAge, v -> state.targetAge = v, true);
            editNumber(baseCard, "Gewünschtes Zielvermögen (€)", state.target, d -> state.target = d, true);
            editNumber(baseCard, "Erwartete Jahresrendite (%)", state.annualRate, d -> state.annualRate = d, true);
        } else {
            editNumber(baseCard, "Monatliche Sparrate (€)", state.monthly, d -> state.monthly = d, state.mode != Finance.MONTHLY);
            LinearLayout runtimeRow = row();
            LinearLayout yearsWrap = col();
            LinearLayout monthsWrap = col();
            runtimeRow.addView(yearsWrap, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, -2, 1);
            mp.leftMargin = dp(8);
            runtimeRow.addView(monthsWrap, mp);
            editInteger(yearsWrap, "Laufzeit in Jahren", state.years, v -> state.years = v, state.mode != Finance.DURATION);
            editInteger(monthsWrap, "Zusätzliche Monate", state.extraMonths, v -> state.extraMonths = v, state.mode != Finance.DURATION && state.expert);
            if (!state.expert) {
                monthsWrap.removeAllViews();
                monthsWrap.addView(smallLabel("Zusätzliche Monate"));
                monthsWrap.addView(text("Im Expertenmodus verfügbar", 14, MUTED, false));
            }
            baseCard.addView(runtimeRow, lp(-1, -2));
            editNumber(baseCard, "Erwartete Jahresrendite (%)", state.annualRate, d -> state.annualRate = d, state.mode != Finance.RATE);
            if (state.mode != Finance.END) editNumber(baseCard, "Gewünschtes Endkapital (€)", state.target, d -> state.target = d, true);
        }

        if (state.expert) {
            LinearLayout optionsCard = card(page);
            sectionTitle(optionsCard, "Erweiterte Optionen", "Feinabstimmung für Steuern, Inflation und den Zahlungszeitpunkt.");
            gap(optionsCard, 14);
            switchRow(optionsCard, "Sparrate jeweils am Monatsanfang", state.depositBeginning, v -> state.depositBeginning = v);
            switchRow(optionsCard, "Steuern grob mitschätzen", state.useTax, v -> state.useTax = v);
            if (state.useTax) {
                editNumber(optionsCard, "Steuersatz inkl. Soli (%)", state.taxRate, d -> state.taxRate = d, true);
                editNumber(optionsCard, "Sparer-Pauschbetrag (€)", state.taxFree, d -> state.taxFree = d, true);
                editNumber(optionsCard, "Teilfreistellung (%)", state.equityExemption, d -> state.equityExemption = d, true);
            }
            switchRow(optionsCard, "Inflation berücksichtigen", state.useInflation, v -> state.useInflation = v);
            if (state.useInflation) {
                editNumber(optionsCard, "Inflationsrate pro Jahr (%)", state.inflation, d -> state.inflation = d, true);
            }
        }

        LinearLayout actionsCard = card(page);
        sectionTitle(actionsCard, "Nächste Schritte", "Speichere dein Szenario oder springe direkt zur Auswertung.");
        gap(actionsCard, 14);
        Button save = primaryButton("Szenario speichern");
        actionsCard.addView(save, lp(-1, 50));
        save.setOnClickListener(v -> saveDialog());
        gap(actionsCard, 10);
        Button go = secondaryButton("Zur Auswertung wechseln");
        actionsCard.addView(go, lp(-1, 50));
        go.setOnClickListener(v -> { tab = 1; render(); });

        refreshResult();
    }

    private String displayDate(String iso) {
        try { return LocalDate.parse(iso).format(DATE_LABEL); }
        catch (Exception e) { return iso; }
    }

    private String euro(double x) { return Double.isFinite(x) ? EURO.format(x) : "–"; }
    private String decimal(double x) { return NUMBER.format(x); }

    private Finance.Result compute() {
        if (state.mode != Finance.GOAL && (state.extraMonths < 0 || state.extraMonths > 11)) {
            Finance.Result x = new Finance.Result();
            x.error = "Zusätzliche Monate müssen zwischen 0 und 11 liegen.";
            return x;
        }
        return Finance.compute(state.inputs());
    }

    private void refreshResult() {
        if (mainResult == null || tab != 0) return;
        Finance.Result r = compute();
        if (!r.valid()) {
            mainResult.setText("–");
            detailResult.setText("Eingaben prüfen");
            explanation.setText(r.error);
            summaryStart.setText("–");
            summaryMonthly.setText("–");
            summaryGain.setText("–");
            return;
        }
        explanation.setText("");
        switch (state.mode) {
            case Finance.START:
                mainResult.setText(euro(r.start));
                break;
            case Finance.MONTHLY:
            case Finance.GOAL:
                mainResult.setText(euro(r.monthly));
                break;
            case Finance.DURATION:
                mainResult.setText((r.months / 12) + " J. " + (r.months % 12) + " M.");
                break;
            case Finance.RATE:
                mainResult.setText(String.format(Locale.GERMANY, "%.3f %%", r.annualRate));
                break;
            default:
                mainResult.setText(euro(r.end));
                break;
        }
        detailResult.setText(String.format(Locale.GERMANY, "Rendite %.2f %% p.a. · Laufzeit %d Jahre %d Monate", r.annualRate, r.months / 12, r.months % 12));
        try {
            LocalDate endDate = LocalDate.parse(state.startDate).plusMonths(r.months);
            detailResult.append("\n" + displayDate(state.startDate) + " bis " + endDate.format(DATE_LABEL));
        } catch (Exception ignored) {}
        summaryStart.setText(euro(r.invested));
        summaryMonthly.setText(euro(r.afterTax));
        summaryGain.setText(euro(r.earnings));
        if (state.expert && state.useInflation) detailResult.append("\nKaufkraft zum Startzeitpunkt: " + euro(r.realValue));
    }

    private void showAnalysis() {
        Finance.Result r = compute();
        LinearLayout head = card(page);
        sectionTitle(head, "Auswertung", "So entwickelt sich dein Szenario über die Zeit.");
        if (!r.valid()) {
            gap(head, 12);
            head.addView(text(r.error, 15, ERROR, false));
            return;
        }

        LinearLayout highlight = card(page);
        highlight.setBackground(gradient(0xFFF9FCFF, 0xFFF3FAF8, 20));
        highlight.addView(smallLabel("Vermögensstand am Ende"));
        gap(highlight, 6);
        highlight.addView(text(euro(r.end), 29, TEXT, true));
        gap(highlight, 14);
        LinearLayout numbers = row();
        addLightMetric(numbers, "Einzahlungen", euro(r.invested));
        addLightMetric(numbers, "Erträge", euro(r.earnings));
        addLightMetric(numbers, state.expert && state.useInflation ? "Kaufkraft" : "Nach Steuern", state.expert && state.useInflation ? euro(r.realValue) : euro(r.afterTax));
        highlight.addView(numbers);

        LinearLayout chartCard = card(page);
        sectionTitle(chartCard, "Vermögensentwicklung", "Blau zeigt dein Gesamtvermögen, Petrol deine Einzahlungen.");
        gap(chartCard, 12);
        chartCard.addView(new ChartView(this, r, state.depositBeginning), lp(-1, 250));

        LinearLayout scenarioCard = card(page);
        sectionTitle(scenarioCard, "Renditevergleich", "Drei Szenarien für einen schnellen Plausibilitätscheck.");
        gap(scenarioCard, 12);
        double basis = r.annualRate;
        for (double d : new double[]{-2, 0, 2}) {
            double alternative = Math.max(-99.0, Math.min(1000, basis + d));
            double fv = Finance.futureValue(r.start, r.monthly, r.months, alternative, state.depositBeginning);
            LinearLayout item = row();
            TextView left = text(String.format(Locale.GERMANY, "%.2f %% p.a.", alternative), 15, d == 0 ? PETROL : TEXT, true);
            item.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
            item.addView(text(euro(fv), 15, TEXT, true));
            scenarioCard.addView(item, lp(-1, -2));
            if (d != 2) {
                View div = new View(this);
                div.setBackgroundColor(BORDER);
                LinearLayout.LayoutParams p = lp(-1, 1);
                p.topMargin = dp(10);
                p.bottomMargin = dp(10);
                scenarioCard.addView(div, p);
            }
        }

        if (state.mode == Finance.GOAL) {
            LinearLayout goalCard = card(page);
            sectionTitle(goalCard, "Monatliche Sparrate für dein Ziel", "So verändert sich der benötigte Monatsbetrag bei unterschiedlicher Rendite.");
            gap(goalCard, 12);
            for (double d : new double[]{-2, 0, 2}) {
                double rate = Math.max(-99, Math.min(1000, basis + d));
                try {
                    double need = Finance.requiredMonthly(r.start, r.months, rate, state.target, state.depositBeginning);
                    goalCard.addView(text(String.format(Locale.GERMANY, "Bei %.2f %%: %s pro Monat", rate, euro(need)), 15, TEXT, false));
                } catch (IllegalArgumentException e) {
                    goalCard.addView(text("Bei " + rate + " %: Ziel bereits erreicht", 15, MUTED, false));
                }
                gap(goalCard, 8);
            }
        }

        LinearLayout table = card(page);
        sectionTitle(table, "Jahresübersicht", "Einzahlungen, Vermögensstand und Gewinn je Zwischenstand.");
        gap(table, 12);
        int last = 0;
        for (int m = 0; m <= r.months; m += 12) {
            addYearRow(table, r, m);
            last = m;
        }
        if (last != r.months) addYearRow(table, r, r.months);

        LinearLayout notes = card(page);
        sectionTitle(notes, "Berechnungsannahmen", null);
        gap(notes, 10);
        notes.addView(text("Konstante effektive Jahresrendite, monatlich umgerechnet. Die Sparrate fließt " +
                (state.depositBeginning ? "am Monatsanfang" : "am Monatsende") +
                " zu. Die Berechnung zeigt ein Modell und ist keine Renditeprognose.", 13, MUTED, false));
        if (state.expert && state.useTax) {
            gap(notes, 8);
            notes.addView(text("Steuern werden vereinfacht als einmalige Endbesteuerung positiver Gewinne behandelt. " +
                    "Vorabpauschalen, Verkäufe während der Laufzeit und Kirchensteuer sind nicht enthalten.", 13, MUTED, false));
        }
    }

    private void addLightMetric(LinearLayout row, String label, String value) {
        LinearLayout box = col();
        box.setBackground(outlined(WHITE, 14, BORDER));
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.addView(text(label, 12, MUTED, true));
        gap(box, 4);
        box.addView(text(value, 15, TEXT, true));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
        if (row.getChildCount() > 0) p.leftMargin = dp(8);
        row.addView(box, p);
    }

    private void addYearRow(LinearLayout table, Finance.Result r, int m) {
        double fv = Finance.futureValue(r.start, r.monthly, m, r.annualRate, state.depositBeginning);
        double in = r.start + r.monthly * m;
        LinearLayout wrap = col();
        wrap.setBackground(outlined(SURFACE_SOFT, 14, BORDER));
        wrap.setPadding(dp(14), dp(12), dp(14), dp(12));
        String title = m == 0 ? "Start" : (m % 12 == 0 ? "Jahr " + (m / 12) : "Jahr " + (m / 12) + " + " + (m % 12) + " Mon.");
        wrap.addView(text(title, 15, TEXT, true));
        gap(wrap, 6);
        wrap.addView(text("Vermögen: " + euro(fv), 14, TEXT, false));
        wrap.addView(text("Einzahlungen: " + euro(in), 13, MUTED, false));
        wrap.addView(text("Gewinn: " + euro(fv - in), 13, PETROL, true));
        if (state.expert && (state.useTax || state.useInflation)) {
            double tax = 0;
            if (state.useTax) {
                double taxable = Math.max(0, (fv - in) * (1 - state.equityExemption / 100) - state.taxFree);
                tax = taxable * state.taxRate / 100;
            }
            double real = state.useInflation ? (fv - tax) / Math.pow(1 + state.inflation / 100, m / 12.0) : (fv - tax);
            wrap.addView(text((state.useInflation ? "Kaufkraftwert: " : "Nach Steuer: ") + euro(real), 13, BLUE, false));
        }
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.bottomMargin = dp(10);
        table.addView(wrap, p);
    }

    private JSONArray savedArray() {
        try { return new JSONArray(storage.getString("saved", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void saveDialog() {
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("z. B. ETF-Sparplan");
        name.setText(state.name.isEmpty() ? "Mein Szenario" : state.name);
        LinearLayout wrap = col();
        wrap.setPadding(dp(20), 0, dp(20), 0);
        wrap.addView(name, lp(-1, -2));
        new AlertDialog.Builder(this)
                .setTitle("Szenario speichern")
                .setView(wrap)
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Speichern", (dialog, which) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) {
                        Toast.makeText(this, "Bitte einen Namen eingeben", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    state.name = n;
                    JSONArray list = savedArray();
                    list.put(state.toJson());
                    storage.edit().putString("saved", list.toString()).apply();
                    persist();
                    Toast.makeText(this, "Gespeichert: " + n, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showSaved() {
        LinearLayout intro = card(page);
        sectionTitle(intro, "Meine Szenarien", "Lokal gespeichert auf deinem Gerät.");
        JSONArray arr = savedArray();
        if (arr.length() == 0) {
            gap(intro, 12);
            intro.addView(text("Hier erscheinen deine gespeicherten Berechnungen. Speichere auf der Rechner-Seite ein Szenario, um es später erneut zu öffnen.", 15, MUTED, false));
            return;
        }
        for (int i = arr.length() - 1; i >= 0; i--) {
            final int index = i;
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            AppState entry = AppState.fromJson(o);
            Finance.Result r = Finance.compute(entry.inputs());
            LinearLayout c = card(page);
            c.addView(text(entry.name, 17, TEXT, true));
            gap(c, 4);
            c.addView(text("Modus: " + MODES[Math.max(0, Math.min(5, entry.mode))], 13, MUTED, false));
            gap(c, 10);
            if (r.valid()) {
                LinearLayout metrics = row();
                addLightMetric(metrics, "Endkapital", euro(r.end));
                addLightMetric(metrics, "Einzahlungen", euro(r.invested));
                addLightMetric(metrics, "Ertrag", euro(r.earnings));
                c.addView(metrics);
                gap(c, 10);
                c.addView(text(String.format(Locale.GERMANY, "Rendite %.2f %% · Dauer %d Jahre %d Monate", r.annualRate, r.months / 12, r.months % 12), 12, MUTED, false));
            }
            gap(c, 12);
            LinearLayout buttons = row();
            Button open = primaryButton("Öffnen");
            buttons.addView(open, new LinearLayout.LayoutParams(0, dp(46), 1));
            Button delete = secondaryButton("Löschen");
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(46), 1);
            p.leftMargin = dp(8);
            buttons.addView(delete, p);
            c.addView(buttons);
            open.setOnClickListener(v -> { state = AppState.fromJson(o); tab = 0; persist(); render(); });
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Szenario löschen?")
                    .setMessage(entry.name)
                    .setNegativeButton("Abbrechen", null)
                    .setPositiveButton("Löschen", (d, w) -> {
                        JSONArray newList = new JSONArray();
                        for (int j = 0; j < arr.length(); j++) if (j != index) newList.put(arr.optJSONObject(j));
                        storage.edit().putString("saved", newList.toString()).apply();
                        render();
                    }).show());
        }
    }

    private void showSettings() {
        LinearLayout intro = card(page);
        sectionTitle(intro, "Einstellungen & Hinweise", "Datenschutzfreundlich, lokal und ohne Konto.");

        LinearLayout c1 = card(page);
        sectionTitle(c1, "Privatsphäre", null);
        gap(c1, 8);
        c1.addView(text("Alle Berechnungen und gespeicherten Szenarien liegen nur auf diesem Gerät. Keine Registrierung, kein Tracking und kein Internetzugriff.", 14, MUTED, false));

        LinearLayout c2 = card(page);
        sectionTitle(c2, "Renditemodell", null);
        gap(c2, 8);
        c2.addView(text("Die Jahresrendite ist effektiv. Der monatliche Zins wird aus der effektiven Jahresrendite umgerechnet. Alle Einzahlungen sind monatlich.", 14, MUTED, false));

        LinearLayout c3 = card(page);
        sectionTitle(c3, "Steuern", null);
        gap(c3, 8);
        c3.addView(text("26,375 % sind eine vereinfachte Annahme für Kapitalertragsteuer plus Soli ohne Kirchensteuer. Die Teilfreistellung kann angepasst werden. Die Ergebnisse bleiben eine Näherung.", 14, MUTED, false));

        LinearLayout c4 = card(page);
        sectionTitle(c4, "Version", null);
        gap(c4, 8);
        c4.addView(text("UI-Überarbeitung 2.1 · native Android-App · Android 8.0+", 14, MUTED, false));
    }

    /** Device independent interactive graph, rendered with Android Canvas. */
    private final class ChartView extends View {
        private final Finance.Result r;
        private final boolean beginning;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ChartView(Context c, Finance.Result result, boolean begin) {
            super(c);
            r = result;
            beginning = begin;
            setBackground(outlined(WHITE, 14, BORDER));
            if (Build.VERSION.SDK_INT >= 21) setElevation(dpf(1));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float left = dpf(16), right = w - dpf(16), top = dpf(16), bottom = h - dpf(28);
            double max = Math.max(r.end, r.invested) * 1.05;
            if (max <= 0) max = 1;

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpf(1));
            paint.setColor(BORDER);
            for (int k = 0; k <= 4; k++) {
                float y = top + (bottom - top) * k / 4f;
                canvas.drawLine(left, y, right, y, paint);
            }

            for (int j = 0; j < 2; j++) {
                Path p = new Path();
                for (int step = 0; step <= 90; step++) {
                    int m = r.months * step / 90;
                    double value = j == 0 ? Finance.futureValue(r.start, r.monthly, m, r.annualRate, beginning) : r.start + r.monthly * m;
                    float x = left + (right - left) * (r.months == 0 ? 0 : ((float) m / r.months));
                    float y = bottom - (float) (value / max) * (bottom - top);
                    if (step == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                paint.setColor(j == 0 ? BLUE : PETROL);
                paint.setStrokeWidth(dpf(3));
                canvas.drawPath(p, paint);
            }

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(MUTED);
            paint.setTextSize(12 * getResources().getDisplayMetrics().scaledDensity);
            canvas.drawText("Start", left, bottom + dpf(18), paint);
            String finish = String.format(Locale.GERMANY, "%.1f J.", r.months / 12.0);
            canvas.drawText(finish, right - paint.measureText(finish), bottom + dpf(18), paint);
        }
    }
}
